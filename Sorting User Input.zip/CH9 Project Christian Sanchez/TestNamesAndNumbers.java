import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ChrisSanchez
 */
public class TestNamesAndNumbers {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Do you want to start the program (yes/no)? ");
        String answer = s.nextLine();

        if (answer.equalsIgnoreCase("yes")) {
            startMenu();
        } else {
            System.out.println("Thank you for using my program.");
        }
    }

    public static void startMenu() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Do you want to enter names or numbers (names / numbers)? ");
        String choice = sc.next();

        if (choice.equalsIgnoreCase("names")) {
            System.out.println("How many " + choice + " would you like to enter?");
            int size = sc.nextInt();

            Names names = new Names();
            names.initializeArray(size);

            names.acceptValues();
            System.out.println("Thank you for entering " + size + " names.");

            System.out.println("Would you like to display them in a sorted or unsorted manner (sorted / unsorted)? ");
            sc.nextLine();
            String sortedOrUnsorted = sc.nextLine();

            // System.out.println("***sortedOrUnsorted: " + sortedOrUnsorted);
            if (sortedOrUnsorted.equalsIgnoreCase("sorted") || sortedOrUnsorted.equalsIgnoreCase("unsorted")) {
                while (sortedOrUnsorted.equalsIgnoreCase("sorted") || sortedOrUnsorted.equalsIgnoreCase("unsorted")) {
                    // System.out.println("***while");
                    if (sortedOrUnsorted.equalsIgnoreCase("unsorted")) {
                        names.printOriginalArray();
                    } else if (sortedOrUnsorted.equalsIgnoreCase("sorted")) {
                        System.out.println("How would you like to display your names, ascending or descending or quit?");

                        String ascendingOrDescending = sc.nextLine();
                        if (ascendingOrDescending.equalsIgnoreCase("ascending")) {
                            names.sortAscendingAndDisplay();
                            System.out.println("Done printing in Ascending Order...");
                        } else if (ascendingOrDescending.equalsIgnoreCase("descending")) {
                            names.sortDescendingAndDisplay();
                            System.out.println("Done printing in Descending Order...");

                        }
                        else if (ascendingOrDescending.equalsIgnoreCase("quit"))
                        {
                            System.out.println("Thank you for using the program, quitting...");
                            System.exit(0);
                        }
                        else {
                            System.out.println("Incorrect option...");
                            System.out.println("Would you like to display them in a sorted manner (sorted / unsorted)? ");
                            sortedOrUnsorted = sc.nextLine();
                            continue;
                        }
                    } ////
                    else {
                        System.out.println("Incorrect option...");
                        System.out.println("Would you like to display them in a sorted manner (sorted / unsorted)? ");
                        sortedOrUnsorted = sc.nextLine();
                        continue;
                    }

                    ////
                    //System.out.println("Do you want to restart the program? ");
                }
            }
            else
            {
                System.out.println("Incorrect option...");
                startMenu();
            }

        } else if (choice.equalsIgnoreCase("numbers")) {
////////////

//            System.out.println("Numbers");
//            System.out.println("How many " + choice + " would you like to enter?");
//            int numberOfInputs = sc.nextInt();
////////////
            System.out.println("How many " + choice + " would you like to enter?");
            int size = sc.nextInt();

            Numbers numbers = new Numbers();
            numbers.initializeArray(size);

            numbers.acceptValues();
            System.out.println("Thank you for entering " + size + " numbers.");

            System.out.println("Would you like to display them in a sorted or unsorted manner (sorted / unsorted)? ");
            sc.nextLine();
            String sortedOrUnsorted = sc.nextLine();

            // System.out.println("***sortedOrUnsorted: " + sortedOrUnsorted);
            if (sortedOrUnsorted.equalsIgnoreCase("sorted") || sortedOrUnsorted.equalsIgnoreCase("unsorted")) {
                while (sortedOrUnsorted.equalsIgnoreCase("sorted") || sortedOrUnsorted.equalsIgnoreCase("unsorted")) {
                    // System.out.println("***while");
                    if (sortedOrUnsorted.equalsIgnoreCase("unsorted")) {
                        numbers.printOriginalArray();
                    } else if (sortedOrUnsorted.equalsIgnoreCase("sorted")) {
                        System.out.println("How would you like to display your numbers, ascending or descending or quit?");

                        String ascendingOrDescending = sc.nextLine();
                        if (ascendingOrDescending.equalsIgnoreCase("ascending")) {
                            numbers.sortAscendingAndDisplay();
                            System.out.println("Done printing in Ascending Order...");
                        } else if (ascendingOrDescending.equalsIgnoreCase("descending")) {
                            numbers.sortDescendingAndDisplay();
                            System.out.println("Done printing in Descending Order...");

                        }
                        else if (ascendingOrDescending.equalsIgnoreCase("quit"))
                        {
                            System.out.println("Thank you for using the program, quitting...");
                            System.exit(0);
                        }
                        else {
                            System.out.println("Incorrect option...");
                            System.out.println("Would you like to display them in a sorted manner (sorted / unsorted)? ");
                            sortedOrUnsorted = sc.nextLine();
                            continue;
                        }
                    } ////
                    else {
                        System.out.println("Incorrect option...");
                        System.out.println("Would you like to display them in a sorted manner (sorted / unsorted)? ");
                        sortedOrUnsorted = sc.nextLine();
                        continue;
                    }

                    ////
                    //System.out.println("Do you want to restart the program? ");
                }
            }
            else
            {
                System.out.println("Incorrect option...");
                startMenu();
            }


////////
        } else {
            System.out.println("Incorrect choice, please enter the correct option.");
            startMenu();
        }
    }

}