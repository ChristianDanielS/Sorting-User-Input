import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Names {

    private String names[];
    private int arraySize;

    public void initializeArray(int arraySize)
    {
        names = new String[arraySize];
        this.arraySize = arraySize;
    }

    public void acceptValues()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter " + arraySize + " names: ");
        for (int i = 0; i < names.length; i++)
        {
            names[i] = s.next();
        }
        return;
        //s.close();
    }

    public void sortAscendingAndDisplay()
    {
        Arrays.sort(names);
        System.out.println("Names in ascending order: ");
        for (int i = 0; i < names.length; i++)
        {
            System.out.println(names[i]);
        }
    }

    public void sortDescendingAndDisplay()
    {
        Arrays.sort(names, Collections.reverseOrder());
        System.out.println("Names in descending order: ");
        for (int i = 0; i < names.length; i++)
        {
            System.out.println(names[i]);
        }
    }

    public void printOriginalArray()
    {
        System.out.println("Names: ");
        for (int i = 0; i < names.length; i++)
        {
            System.out.println(names[i]);
        }
    }
}