
import java.util.Arrays;
import java.util.Scanner;


public class Numbers {
    private int numbers[];
    private int arraySize;

    public void initializeArray(int arraySize)
    {
        numbers = new int[arraySize];
        this.arraySize = arraySize;
    }

    public void acceptValues()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter " + arraySize + " numbers: ");
        for (int i = 0; i < numbers.length; i++)
        {
            numbers[i] = s.nextInt();
        }
        return;
        //s.close();
    }

    public void sortAscendingAndDisplay()
    {
        Arrays.sort(numbers);
        System.out.println("Numbers in ascending order: ");
        for (int i = 0; i < numbers.length; i++)
        {
            System.out.println(numbers[i]);
        }
    }

    public void sortDescendingAndDisplay()
    {
        Arrays.sort(numbers);
        System.out.println("Numbers in descending order: ");
        for (int i = numbers.length - 1; i >= 0; i--)
        {
            System.out.println(numbers[i]);
        }
    }

    public void printOriginalArray()
    {
        System.out.println("Numbers in original form: ");
        for (int i = 0; i < numbers.length; i++)
        {
            System.out.println(numbers[i]);
        }
    }

}